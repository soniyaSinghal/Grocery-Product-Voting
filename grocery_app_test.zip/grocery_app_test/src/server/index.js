const express = require('express');
const app = express();
const productList = require('./data/productList.json');


app.use(express.static('dist'));
// app.get('/api/getUsername', (req, res) => res.send({ username: 'test' }));

app.get('/api/productList', (req, res) => {

	return res.send(productList);
});

app.listen(8080, () => console.log('Listening on port 8080!'));


