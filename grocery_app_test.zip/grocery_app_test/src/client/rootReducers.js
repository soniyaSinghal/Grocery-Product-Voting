import { combineReducers } from 'redux';
import { getProductListReducer } from './container/HomePage';


const rootReducer = combineReducers({
	productList: getProductListReducer,
});

export default rootReducer;