import React from 'react';
import PropTypes from 'prop-types';

import Header from '../Header';

class HomePage extends React.Component {

	constructor (props) {
		super(props);

		this.changeVote = this.changeVote.bind(this);
	}

	changeVote(selectedProductId, selectedVoteCount, type) {
		if (type === "upVoted") {
			this.props.increaseProductUpVoteProp(
				{
					"selectedProductId": selectedProductId,
					"upVoteCount": selectedVoteCount + 1
				}
			);
		}
		else if (type === "downVoted") {
			this.props.increaseProductDownVoteProp(
				{
					"selectedProductId": selectedProductId,
					"downVoteCount": selectedVoteCount + 1
				}
			);
		}
	}

	render(){
		return (
			<div>
				<Header heading='Grocery Ratings' />
				<div className='main-container'>
					{this.props.productList.map((productDetails, i) =>
						<div className='product-container'>
							<p key={i} className='product-info'>{productDetails.name}</p>
							<span className='product-vote'>
								<button onClick={(event) => this.changeVote(productDetails.id, productDetails.upVoted, 'upVoted')}>Up Vote</button>
								{productDetails.upVoted}
							</span>
							<span className='product-vote'>
								<button onClick={(event) => this.changeVote(productDetails.id, productDetails.downVoted, 'downVoted')}>Down Vote</button>
								{productDetails.downVoted}
							</span>
						</div>
					)}
				</div>
			</div>
		);
	}
}

HomePage.propTypes = {
	productList: PropTypes.array,
};

export default HomePage;