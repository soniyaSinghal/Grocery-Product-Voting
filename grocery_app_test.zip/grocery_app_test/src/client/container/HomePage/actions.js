export function fetchProductList() {
	return {
		type: 'fetch_product_list',
	};
}

export function increaseProductUpVote(data) {
	return {
		type: 'increase_up_vote',
		payload: data
	};
}

export function increaseProductDownVote(data) {
	return {
		type: 'increase_down_vote',
		payload: data
	};
}