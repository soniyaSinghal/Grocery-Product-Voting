const defaultState = {
	productList: [],
};

function changeVote(state, payload, type) {
		let tempProductList = Array.from(state.productList);
		let valueToBeChanged = tempProductList.findIndex(item => item.id === payload.selectedProductId);

		if (type === 'changeUpVote') {
			tempProductList[valueToBeChanged].upVoted = payload.upVoteCount;
		}
		else if (type === 'changeDownVote') {
			tempProductList[valueToBeChanged].downVoted = payload.downVoteCount;
		}
		return tempProductList;
}

export default function citiesReducer(state = defaultState , action) {
	switch(action.type) {
	case 'fetch_product_list_success':
		return {productList: action.data.productList};
	case 'increase_up_vote':
		return {...state, productList: changeVote(state, action.payload, 'changeUpVote') }
	case 'increase_down_vote':
		return { ...state, productList: changeVote(state, action.payload, 'changeDownVote') }
	default:
		return state;
	}
}