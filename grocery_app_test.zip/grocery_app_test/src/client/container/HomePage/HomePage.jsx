import React from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';

import HomePageComponent from '../../component/HomePage';
import { fetchProductList, increaseProductUpVote, increaseProductDownVote } from './actions';

class HomePage extends React.Component {
	constructor(props) {
		super(props);

		this.increasedProductUpVote = this.increasedProductUpVote.bind(this);
		this.increasedProductDownVote = this.increasedProductDownVote.bind(this);
	}

	componentDidMount() {
		this.props.fetchProductList();
	}

	increasedProductUpVote(data) {
		this.props.increaseProductUpVote(data);
	}

	increasedProductDownVote(data) {
		this.props.increaseProductDownVote(data);
	}

	render() {
		return (
			<div>
				<HomePageComponent
					productList={this.props.productList}
					increaseProductUpVoteProp={this.increasedProductUpVote}
					increaseProductDownVoteProp={this.increasedProductDownVote}
					/>
			</div>
		);
	}
}

HomePage.propTypes = {
	fetchProductList: PropTypes.func,
	increaseProductUpVote: PropTypes.func,
	increaseProductDownVote: PropTypes.func,
	productList: PropTypes.array,
};

function mapDispatchToProps(disaptch) {
	return bindActionCreators(
		{
			fetchProductList,
			increaseProductUpVote,
			increaseProductDownVote
		},
		disaptch);
}

function mapStateToProps(state) {
	return { productList: state.productList.productList };
}

export default connect(mapStateToProps, mapDispatchToProps)(HomePage);