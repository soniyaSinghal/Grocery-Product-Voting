import {call, takeLatest, put} from 'redux-saga/effects';
import axios from 'axios';

function* getProductListSagas() {
	yield takeLatest('fetch_product_list', getProductList);
}

function fetchProductList() {
	return axios({
		method: 'get',
		url: '/api/productList'
	});
}

function* getProductList() {
	try {
		const response = yield call(fetchProductList);
		// dispatch a success action to the store with the new data
		yield put({ type: 'fetch_product_list_success', data: response.data });

	} catch (error) {
		// dispatch a failure action to the store with the error
		// yield put({ type: 'API_CALL_FAILURE', error });
	}
}

export default [getProductListSagas];