import { all, fork } from 'redux-saga/effects';

import { getProductListSagas } from './container/HomePage';

export default function* rootSagas() {
	yield all([
		...getProductListSagas,
	].map(fork));
}